const CACHE_NAME = "tea-tracker-cache-v1";

const ASSETS = [
        "./",
        "./index.html",
        "./style.css",
        "./app.js",
        "./manifest.json",
        "./icons/icon-192.png",
        "./icons/icon-512.png"
];

// install: cache all files
self.addEventListener("install", event => {
        event.waitUntil(
                caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
        );
        self.skipWaiting();
});

// activate: remove old caches
self.addEventListener("activate", event => {
        event.waitUntil(
                caches.keys().then(keys =>
                        Promise.all(
                                keys
                                        .filter(k => k !== CACHE_NAME)
                                        .map(k => caches.delete(k))
                        )
                )
        );
        self.clients.claim();
});

// fetch: serve cached files if offline
self.addEventListener("fetch", event => {
        event.respondWith(
                caches.match(event.request).then(cached => {
                        return (
                                cached ||
                                fetch(event.request).catch(() => {
                                        // fallback: show homepage if offline
                                        return caches.match("./index.html");
                                })
                        );
                })
        );
});
